import com.company.StudentInfo;
public class Test {

	public static void main(String[] args) {
		
		StudentInfo si1 = new StudentInfo ("UST", 131969, "Catherine Tolentino");
		System.out.println("Student Number: " + si1.getstudentNo());
		System.out.println("Name of school: " + si1.getschool());
		System.out.println("Name of Student: " + si1.getname());
		
		StudentInfo si2 = new StudentInfo ("UST", 129787, "Ella Berdal");
		System.out.println("\nStudent Number: " + si2.getstudentNo());
		System.out.println("Name of school: " + si2.getschool());
		System.out.println("Name of Student: " + si2.getname());
		
		StudentInfo si3 = new StudentInfo ("CEU", 30583, "Arn Yanga");
		System.out.println("\nStudent Number: " + si3.getstudentNo());
		System.out.println("Name of school: " + si3.getschool());
		System.out.println("Name of Student: " + si3.getname());
	}

}
