package com.company;

public class StudentInfo {
	
	private String school;
	private int studentNo;
	private String name;
	
	public StudentInfo(String school, int studentNo, String name) {
		this.school = school;
		this.studentNo = studentNo;
		this.name = name;
	}
	
	public String getschool() {
		return this.school;
	}
	
	public int getstudentNo() {
		return this.studentNo;
	}
	
	public String getname() {
		return this.name;
	}
	
}
