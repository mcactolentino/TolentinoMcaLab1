package com.company;

public class tester {

	public static void main(String[] args) {
		
		StudentInfo si1 = new StudentInfo ("He", 20, "whue");
		System.out.println("hsekj: " + si1.getstudentNo());
		System.out.println("school: " + si1.getschool());
		System.out.println("shaksj " + si1.getname());
	}

}
